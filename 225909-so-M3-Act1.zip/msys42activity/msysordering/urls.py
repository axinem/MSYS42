from django.urls import path
from . import views

urlpatterns = [
    path('', views.openpos_view, name='openpos'),
    path('item_list.html/', views.item_list_view, name='item_list'),
    path('item_form.html/', views.item_form, name='item_form'),
    path('edit_item/<int:pk>/', views.edit_item, name='edit_item'),
    path('delete_item/<int:pk>/', views.delete_item, name='delete_item'),
]
